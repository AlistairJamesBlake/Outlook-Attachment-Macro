# Ensure Outlook is closed before running this script

# Create a new Outlook Application instance
$Outlook = New-Object -ComObject Outlook.Application
$Namespace = $Outlook.GetNameSpace("MAPI")
$Outlook.Visible = $True

# Access the VBA project (assumes there is only one project)
$VBAProject = $Outlook.Application.VBE.ActiveVBProject

# Path to the directory containing .bas files
$Folder = "C:\Users\User\Documents\Outlook Marcos Attachments\BAS Files"

# Iterate over each .bas file in the folder
Get-ChildItem -Path $Folder -Filter *.bas | ForEach-Object {
    $FilePath = $_.FullName
    $FileName = [System.IO.Path]::GetFileNameWithoutExtension($FilePath)

    # Import the .bas file into the VBA project
    $VBAProject.VBComponents.Import($FilePath)
    $NewComponent = $VBAProject.VBComponents.Item($VBAProject.VBComponents.Count)

    # Rename the imported component to match the file name
    $NewComponent.Name = $FileName
}

# Clean up COM objects
$Outlook.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($Outlook) | Out-Null
[System.GC]::Collect()
[System.GC]::WaitForPendingFinalizers()
